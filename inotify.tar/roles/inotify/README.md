# Longhorn Taints

## K8s1-RHEL:
```bash
ansible-playbook -i inventory/k8s1_rhel.yaml inotify.yaml -b
```