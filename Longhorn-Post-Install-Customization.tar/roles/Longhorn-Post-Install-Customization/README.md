# Longhorn post install customization

## K8s1-RHEL:
```bash
ansible-playbook -i inventory/k8s1_rhel.yaml Longhorn_Post-Install-Customization.yaml -b
```